What is PSMAME PLUS?

This is a special mini edition of the Shadow Project emulator, which uses the source code from the HBMAME 0.215 emulator. This version was used, since it has a submenu of a cheat that adjusts the automatic trigger, which was removed in the current update.

The beginning of this project was in 2019, where I offer users the pleasure of being able to play all the franchises of the Metal Slug games of the "Neo Geo MVS" arcade system.

It will also include unofficial versions known as "hacks".

Please note that the use of this emulator is prohibited for any commercial use or the project was used for an economic fundraiser.
